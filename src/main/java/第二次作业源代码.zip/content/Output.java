package content;

/**
 * @author 24047
 * @date 2022/9/20
 */
public interface Output {
    void output();
}
